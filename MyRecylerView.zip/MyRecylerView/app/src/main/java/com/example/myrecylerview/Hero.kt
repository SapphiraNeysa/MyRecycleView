package com.example.myrecylerview

data class Hero(
    var name: String = "",
    var from: String = "",
    var photo: String = "")
